import os
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import requests
from google import genai
import json# Import the GenAI module

# Initialize the GenAI client with your API key
client = genai.Client(api_key="AIzaSyB6P-XKANVvaQR9YBCcDIRfN0kiTaPqpoQ")
# Initialize Flask app
app = Flask(__name__)

# Configurations
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:Sravani123@localhost/ai_learning_platform'  # Replace with your database credentials
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.urandom(24)  # For session management and security

# Initialize Database
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# User model
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(255), unique=True, nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(255))
    role = db.Column(db.String(50), default='student')  # 'student' or 'admin'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<User {self.username}>"

    # Hash the password before storing it
    def set_password(self, password):
        self.password = generate_password_hash(password)

    # Check the password when logging in
    def check_password(self, password):
        return check_password_hash(self.password, password)


# Course model
class Course(db.Model):
    __tablename__ = 'courses'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Course {self.name}>"


# Assignment model
class Assignment(db.Model):
    __tablename__ = 'assignments'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    due_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Assignment {self.title}>"



# Quiz model
class Quiz(db.Model):
    __tablename__ = 'quizzes'
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Quiz {self.title}>"



# Performance model
class Performance(db.Model):
    __tablename__ = 'performance'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    total_score = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Performance User {self.user_id} - Score {self.total_score}>"

# Routes
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):  # Verify the password
            session['user_id'] = user.id
            return redirect(url_for('dashboard'))
        return 'Invalid credentials'
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        full_name = request.form['full_name']
        new_user = User(username=username, email=email, full_name=full_name)
        new_user.set_password(password)  # Hash the password
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html')


@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user = User.query.get(session['user_id'])
    courses = Course.query.all()
    return render_template('dashboard.html', user=user, courses=courses)


@app.route('/courses')
def courses():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    courses = Course.query.all()  # Fetch all courses from the database
    return render_template('courses.html', courses=courses)



# Dummy courses data

GEMINI_API_KEY = 'AIzaSyB6P-XKANVvaQR9YBCcDIRfN0kiTaPqpoQ'  # Your API key

@app.route('/course/<int:course_id>', methods=['GET', 'POST'])
def course_details(course_id):
    # Mock data for courses
    courses_data = [
        {"id": 1, "name": "Java Basics"},
        {"id": 2, "name": "Python Basics"}
    ]

    # Quiz questions, options, and correct answers
    quiz_questions = {
        1: {"question": "What is the output of 5+5?", "options": ["10", "15", "20"], "answer": "10"},
        2: {"question": "What is the keyword to define a function in Python?", "options": ["def", "function", "func"], "answer": "def"},
        3: {"question": "What does JVM stand for?", "options": ["Java Virtual Machine", "Java Versatile Machine", "Java Virtual Model"], "answer": "Java Virtual Machine"},
        4: {"question": "How do you declare a variable in Java?", "options": ["int x = 5;", "x = 5", "var = 5"], "answer": "int x = 5;"},
        5: {"question": "What is Python used for?", "options": ["Web development", "Data science", "All of the above"], "answer": "All of the above"}
    }

    # Find the course by ID
    course = next((course for course in courses_data if course["id"] == course_id), None)
    if not course:
        return "Course not found", 404

    grade = None
    generated_content = None
    user_answers = {}
    correct_answers = {i: quiz_questions[i]['answer'] for i in quiz_questions}
    display_correct_answers = False
    score = 0
    total_answered = 0  # Tracks the number of questions the user answered

    if request.method == 'POST':
        # Handle learner type and content generation
        learner_type = request.form.get('learner_type')
        search_query = request.form.get('search_query')

        if learner_type and search_query:
            try:
                # Generate content based on learner type and search query
                client = genai.Client(api_key="AIzaSyB6P-XKANVvaQR9YBCcDIRfN0kiTaPqpoQ")
                prompt_content = f"Generate content for '{search_query}' in {course['name']} suitable for {learner_type} learners."

                if learner_type == "fast":
                    prompt_content += " Provide concise and essential details only."
                elif learner_type == "medium":
                    prompt_content += " Provide detailed explanations and insights."
                elif learner_type == "slow":
                    prompt_content += " Provide an in-depth and thorough explanation with examples and additional context."

                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents=prompt_content
                )

                # Format the generated content into HTML
                raw_content = response.text
                formatted_content = f"<h3>Generated Content:</h3><p>{raw_content.replace('\n', '<br>')}</p>"
                generated_content = formatted_content
            except Exception as e:
                generated_content = f"<p style='color: red;'>An error occurred: {str(e)}</p>"

        # Process quiz submission and grade calculation
        else:
            user_answers = {int(k.split('_')[1]): v for k, v in request.form.items() if k.startswith('question_')}
            total_answered = len(user_answers)  # Count how many questions the user answered
            score = sum(1 for i, ans in user_answers.items() if ans == correct_answers.get(i))  # Calculate correct answers

            # Assign grades based on score
            if score == total_answered and total_answered == len(quiz_questions):  # Full marks
                grade = "A"
            elif score >= total_answered * 0.6:  # At least 60% of the questions answered correctly
                grade = "B"
            else:
                grade = "C"

            # Display correct answers and grade
            display_correct_answers = True

    return render_template(
        'course_details.html',
        course=course,
        quiz_questions=quiz_questions,
        correct_answers=correct_answers,
        user_answers=user_answers,
        score=score,
        total_answered=total_answered,
        grade=grade,
        generated_content=generated_content,
        display_correct_answers=display_correct_answers
    )
# Define the assignments for Python and Java
python_assignments = [
    "1. Write a Python program to check whether a number is prime or not.",
    "2. Write a Python function to find the factorial of a number.",
    "3. Write a Python program to count the frequency of words in a given string.",
    "4. Write a Python program to reverse a string without using the built-in reverse function.",
    "5. Write a Python program to merge two lists into a single list in sorted order."
]

java_assignments = [
    "1. Write a Java program to check whether a number is prime or not.",
    "2. Write a Java function to find the factorial of a number.",
    "3. Write a Java program to count the frequency of characters in a given string.",
    "4. Write a Java program to find the largest of three numbers.",
    "5. Write a Java program to sort an array of integers in ascending order."
]

# Route to Generate and Submit Assignments
@app.route('/assignments', methods=['GET', 'POST'])
def assignments():
    if request.method == 'POST':
        # Get the type of assignment to generate
        course_name = request.form.get('generate_assignment')

        if course_name == 'python':
            assignments = python_assignments
        elif course_name == 'java':
            assignments = java_assignments
        else:
            assignments = []

        return render_template('assignments.html', assignments=assignments, course_name=course_name)

    return render_template('assignments.html')


@app.route('/submit_assignment', methods=['POST'])
def submit_assignment():
    if 'file' in request.files:
        file = request.files['file']
        # Process file upload here (e.g., save it, validate it, etc.)
        # For simplicity, let's just return a grade
        grade = "A+"  # Simulated grade
        return render_template('assignments.html', grade=grade)

    return redirect(url_for('assignments'))

# Initialize the GenAI client
client = genai.Client(api_key="AIzaSyB6P-XKANVvaQR9YBCcDIRfN0kiTaPqpoQ")

@app.route('/quizzes', methods=['GET', 'POST'])
def quizzes():
    python_questions = []  # List to store Python quiz questions
    java_questions = []  # List to store Java quiz questions
    show_quiz = False
    error_message = None  # Variable to store error messages

    if request.method == 'POST':
        # Check if the user clicked "Generate Python Quiz"
        if request.form.get('generate_quiz') == 'python':
            try:
                # Generate Python quiz using GenAI
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents="Generate a Python quiz in JSON format with questions, multiple-choice options, and correct answers."
                )
                print("Python API Response Text:", response.text)  # Debugging log
                python_questions = parse_genai_response(response.text)
                if python_questions:
                    show_quiz = True
                else:
                    error_message = "Failed to generate Python quiz. The response was empty or invalid."
            except Exception as e:
                error_message = f"Error generating Python quiz: {e}"

        # Check if the user clicked "Generate Java Quiz"
        elif request.form.get('generate_quiz') == 'java':
            try:
                # Generate Java quiz using GenAI
                response = client.models.generate_content(
                    model="gemini-2.0-flash",
                    contents="Generate a Java quiz in JSON format with questions, multiple-choice options, and correct answers."
                )
                print("Java API Response Text:", response.text)  # Debugging log
                java_questions = parse_genai_response(response.text)
                if java_questions:
                    show_quiz = True
                else:
                    error_message = "Failed to generate Java quiz. The response was empty or invalid."
            except Exception as e:
                error_message = f"Error generating Java quiz: {e}"

    return render_template(
        'quizzes.html',
        python_questions=python_questions,
        java_questions=java_questions,
        show_quiz=show_quiz,
        error_message=error_message
    )

# Helper function to parse the API response
def parse_genai_response(response_text):
    questions = []
    try:
        # Parse the JSON-formatted response from the API
        quiz_data = json.loads(response_text)
        for question_data in quiz_data.get('questions', []):
            questions.append({
                "question": question_data.get("question", ""),
                "options": question_data.get("options", []),
                "answer": question_data.get("answer", "")
            })
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON from response text: {e}")
    except Exception as e:
        print(f"Unexpected error while parsing response: {e}")
    return questions


@app.route('/performance')
def performance():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    performance_data = Performance.query.filter_by(user_id=session['user_id']).all()
    return render_template('performance.html', performance_data=performance_data)


# Main function to start the app
def main():
    app.run(debug=True)

# Run the app if this script is executed directly
if __name__ == '__main__':
    main()