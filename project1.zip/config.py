import psycopg2

DATABASE_URL = 'postgres://postgres:Sravani123@localhost/ai_learning_platform'

def get_db_connection():
    conn = psycopg2.connect(DATABASE_URL)
    return conn
